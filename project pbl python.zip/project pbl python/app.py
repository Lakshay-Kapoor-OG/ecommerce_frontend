import json
import sys
from flask import Flask, jsonify, request
import subprocess
import os
from flask_cors import CORS

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # enable frontend communication

# --- LOGIC RUNNER ---

def run_logic_command(args):
    """
    Runs main.py with the given arguments and expects clean JSON output.
    Returns: (data_dict, status_code)
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))
    script_path = os.path.join(base_dir, 'main.py')

    if not os.path.exists(script_path):
        return {"error": "main.py logic file not found."}, 500

    command = ['python', script_path] + args
    
    try:
        result = subprocess.run(
            command, 
            capture_output=True, 
            text=True, 
            timeout=10,
            encoding='utf-8'
        )
        output = result.stdout.strip()
        
        # Log stderr for debugging purposes
        if result.stderr:
            print(f"DEBUG: Logic stderr: {result.stderr}", file=sys.stderr) 

        if not output:
            error_msg = result.stderr.strip() if result.stderr else "No output"
            return {"error": "No output from main.py", "details": error_msg}, 500

        try:
            data = json.loads(output)
            return data, 200
        except json.JSONDecodeError as e:
            return {
                "error": "Invalid JSON from main.py", 
                "raw": output, 
                "stderr": result.stderr.strip(),
                "json_error": str(e)
            }, 500

    except subprocess.TimeoutExpired:
        return {"error": "main.py execution timed out (>10s)"}, 504
    except Exception as e:
        return {"error": f"Failed to run main.py: {str(e)}"}, 500

# --- ROUTES ---

@app.route('/')
def index():
    """Health check endpoint"""
    return jsonify({
        "status": "OK",
        "message": "E-Commerce Recommendation System API is running",
        "endpoints": [
            "GET /getProducts - List all products",
            "GET /getUsers - List all users",
            "POST /addProduct - Add new product",
            "POST /addUser - Add new user",
            "POST /purchase - Record a purchase",
            "POST /rate - Rate a product",
            "GET /recommend?userId=<id> - Get recommendations",
            "DELETE /deleteProduct/<id> - Delete a product",
            "DELETE /deleteUser/<id> - Delete a user"
        ]
    }), 200

# --- READ OPERATIONS ---

@app.route("/get/products", methods=["GET"])
@app.route("/getProducts", methods=["GET"])
def get_products():
    """
    Get all products with their ratings.
    Calls: python main.py --get products
    """
    data, status = run_logic_command(["--get", "products"])
    return jsonify(data), status


@app.route('/get/users', methods=['GET'])
@app.route('/getUsers', methods=['GET'])
def get_users():
    """
    Get all registered users.
    Calls: python main.py --get users
    """
    data, status = run_logic_command(['--get', 'users'])
    return jsonify(data), status

# --- CREATE OPERATIONS ---

@app.route('/add/product', methods=['POST'])
@app.route('/addProduct', methods=['POST'])
def add_product():
    """
    Add a new product to inventory.
    Expected JSON: {"name": "...", "category": "...", "price": 99.99}
    Calls: python main.py --add product <name> <category> <price>
    """
    try:
        body = request.get_json(force=True)
        name = body.get("name")
        category = body.get("category")
        price = body.get("price")

        # Validation
        if not name or not name.strip():
            return jsonify({"error": "Product name is required and cannot be empty"}), 400
        
        if not category or not category.strip():
            return jsonify({"error": "Product category is required and cannot be empty"}), 400
        
        if price is None:
            return jsonify({"error": "Product price is required"}), 400
        
        try:
            price_float = float(price)
            if price_float < 0:
                return jsonify({"error": "Price cannot be negative"}), 400
        except (ValueError, TypeError):
            return jsonify({"error": "Price must be a valid number"}), 400

        # Call main.py with validated inputs
        data, status = run_logic_command(["--add", "product", name.strip(), category.strip(), str(price_float)])
        return jsonify(data), status
        
    except Exception as e:
        return jsonify({"error": f"Failed to add product: {str(e)}"}), 400


@app.route('/add/user', methods=['POST'])
@app.route('/addUser', methods=['POST'])
def add_user():
    """
    Add a new user to the system.
    Expected JSON: {"name": "John Doe", "age": "25"} (age is optional)
    Calls: python main.py --add user <name> [age]
    """
    try:
        body = request.get_json(force=True)
        name = body.get("name")
        age = body.get("age", "")  # Age is optional

        # Validation
        if not name or not name.strip():
            return jsonify({"error": "User name is required and cannot be empty"}), 400

        # Prepare arguments
        args = ["--add", "user", name.strip()]
        if age:
            args.append(str(age))

        # Call main.py
        data, status = run_logic_command(args)
        return jsonify(data), status
        
    except Exception as e:
        return jsonify({"error": f"Failed to add user: {str(e)}"}), 400


@app.route('/purchase', methods=['POST'])
def purchase():
    """
    Record a product purchase by a user.
    Expected JSON: {"userId": 100, "productId": 1000}
    Calls: python main.py --purchase <userId> <productId>
    """
    try:
        body = request.get_json(force=True)
        
        if not body or 'userId' not in body or 'productId' not in body:
            return jsonify({"error": "Missing userId or productId in request body"}), 400
        
        # Convert to int to validate
        try:
            userId = int(body['userId'])
            productId = int(body['productId'])
        except (ValueError, TypeError):
            return jsonify({"error": "userId and productId must be valid integers"}), 400
        
        # Call main.py
        data, status = run_logic_command(['--purchase', str(userId), str(productId)])
        return jsonify(data), status
        
    except Exception as e:
        return jsonify({"error": f"Failed to process purchase: {str(e)}"}), 400


@app.route('/rate', methods=['POST'])
def rate():
    """
    Submit a product rating by a user.
    Expected JSON: {"userId": 100, "productId": 1000, "rating": 5}
    Calls: python main.py --rate <userId> <productId> <rating>
    """
    try:
        body = request.get_json(force=True)
        
        if not body or 'userId' not in body or 'productId' not in body or 'rating' not in body:
            return jsonify({"error": "Missing userId, productId, or rating in request body"}), 400

        # Validate and convert
        try:
            userId = int(body['userId'])
            productId = int(body['productId'])
            rating = int(body['rating'])
        except (ValueError, TypeError):
            return jsonify({"error": "userId, productId, and rating must be valid integers"}), 400
        
        # Validate rating range
        if rating < 1 or rating > 5:
            return jsonify({"error": "Rating must be between 1 and 5"}), 400

        # Call main.py
        data, status = run_logic_command(['--rate', str(userId), str(productId), str(rating)])
        return jsonify(data), status
        
    except Exception as e:
        return jsonify({"error": f"Failed to submit rating: {str(e)}"}), 400

# --- RECOMMENDATION ---

@app.route('/recommend', methods=['GET'])
def recommend():
    """
    Get product recommendations for a user.
    Query param: userId (e.g., /recommend?userId=100)
    Calls: python main.py --recommend <userId>
    """
    try:
        userId = request.args.get('userId')
        
        if userId is None:
            return jsonify({"error": "Missing userId query parameter"}), 400

        # Validate userId
        try:
            userId_int = int(userId)
        except (ValueError, TypeError):
            return jsonify({"error": "userId must be a valid integer"}), 400

        # Call main.py
        data, status = run_logic_command(['--recommend', str(userId_int)])
        return jsonify(data), status
        
    except Exception as e:
        return jsonify({"error": f"Failed to generate recommendations: {str(e)}"}), 400

# --- DELETE OPERATIONS ---

@app.route('/delete/user/<int:user_id>', methods=['DELETE'])
@app.route('/deleteUser/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    """
    Delete a user and all their associated data.
    Calls: python main.py --delete user <user_id>
    """
    try:
        # Call main.py
        data, status = run_logic_command(['--delete', 'user', str(user_id)])
        return jsonify(data), status
        
    except Exception as e:
        return jsonify({"error": f"Failed to delete user: {str(e)}"}), 400


@app.route('/delete/product/<int:product_id>', methods=['DELETE'])
@app.route('/deleteProduct/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    """
    Delete a product and all its associated data.
    Calls: python main.py --delete product <product_id>
    """
    try:
        # Call main.py
        data, status = run_logic_command(['--delete', 'product', str(product_id)])
        return jsonify(data), status
        
    except Exception as e:
        return jsonify({"error": f"Failed to delete product: {str(e)}"}), 400

# --- Run Flask App ---
if __name__ == '__main__':
    print("=" * 70)
    print("🚀 E-Commerce Recommendation System API Starting...")
    print("=" * 70)
    print("📍 Server URL: http://127.0.0.1:5000")
    print("📂 Make sure 'main.py' exists in the same directory")
    print("📂 Make sure 'data/' folder exists with JSON files")
    print("=" * 70)
    app.run(debug=True, port=5000)