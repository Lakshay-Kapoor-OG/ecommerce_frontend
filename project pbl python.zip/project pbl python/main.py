import sys
import json
import os

# --- File Paths with data/ folder ---
# Get the directory where this script is located
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(SCRIPT_DIR, 'data')
USERS_FILE = os.path.join(DATA_DIR, 'users.json')
PRODUCTS_FILE = os.path.join(DATA_DIR, 'products.json')
REVIEWS_FILE = os.path.join(DATA_DIR, 'reviews.json')

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

# Debug: Log file paths (written to stderr so it doesn't interfere with JSON output)
import sys as _sys
print(f"DEBUG: Script directory: {SCRIPT_DIR}", file=_sys.stderr)
print(f"DEBUG: Data directory: {DATA_DIR}", file=_sys.stderr)
print(f"DEBUG: Users file: {USERS_FILE}", file=_sys.stderr)

# --- Utility Functions ---

def read_json(filepath):
    """
    Safely read JSON file. If file doesn't exist or is empty, return empty list.
    """
    if not os.path.exists(filepath):
        return []
    
    if os.path.getsize(filepath) == 0:
        return []
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data if isinstance(data, list) else []
    except json.JSONDecodeError:
        # If JSON is malformed, return empty list
        return []
    except Exception:
        return []


def write_json(filepath, data):
    """
    Write data to JSON file with proper formatting.
    """
    try:
        # Debug logging
        print(f"DEBUG: Attempting to write to: {filepath}", file=sys.stderr)
        print(f"DEBUG: File exists before write: {os.path.exists(filepath)}", file=sys.stderr)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        # Verify the write was successful
        print(f"DEBUG: File exists after write: {os.path.exists(filepath)}", file=sys.stderr)
        print(f"DEBUG: File size after write: {os.path.getsize(filepath)} bytes", file=sys.stderr)
        
        return True
    except Exception as e:
        print(f"DEBUG ERROR: Failed to write to {filepath}: {str(e)}", file=sys.stderr)
        print(json.dumps({"status": "error", "message": f"Failed to write to {filepath}: {str(e)}"}))
        return False


def user_exists(user_id):
    """Check if a user with given ID exists."""
    users = read_json(USERS_FILE)
    return any(u.get('id') == user_id for u in users)


def product_exists(product_id):
    """Check if a product with given ID exists."""
    products = read_json(PRODUCTS_FILE)
    return any(p.get('id') == product_id for p in products)


def calculate_product_ratings(product_id):
    """
    Calculate average rating and review count for a product.
    Returns: (avg_rating, reviews_count)
    """
    reviews = read_json(REVIEWS_FILE)
    product_reviews = [r for r in reviews if r.get('product_id') == product_id]
    
    if not product_reviews:
        return 0.0, 0
    
    total_rating = sum(r.get('rating', 0) for r in product_reviews)
    count = len(product_reviews)
    avg_rating = round(total_rating / count, 2) if count > 0 else 0.0
    
    return avg_rating, count


def update_all_product_ratings():
    """
    Update avg_rating and reviews_count for all products based on reviews.json
    """
    products = read_json(PRODUCTS_FILE)
    
    for product in products:
        product_id = product.get('id')
        avg_rating, reviews_count = calculate_product_ratings(product_id)
        product['avg_rating'] = avg_rating
        product['reviews_count'] = reviews_count
    
    write_json(PRODUCTS_FILE, products)
    return products


# ============================================================================
# COMMAND HANDLERS
# ============================================================================

# --- ADD USER ---
# Command: python main.py --add user <name> [age]
if '--add' in sys.argv and 'user' in sys.argv:
    try:
        idx = sys.argv.index('user')
        
        if len(sys.argv) < idx + 2:
            print(json.dumps({"status": "error", "message": "Missing user name"}))
            sys.exit(1)
        
        name = sys.argv[idx + 1].strip()
        age = sys.argv[idx + 2] if len(sys.argv) > idx + 2 else ""
        
        if not name:
            print(json.dumps({"status": "error", "message": "User name cannot be empty"}))
            sys.exit(1)
        
        users = read_json(USERS_FILE)
        
        # Check for duplicate name
        if any(u.get('name', '').lower() == name.lower() for u in users):
            print(json.dumps({"status": "error", "message": "User with this name already exists"}))
            sys.exit(1)
        
        # Generate new ID
        new_id = max([u.get('id', 0) for u in users], default=0) + 1
        
        new_user = {
            "id": new_id,
            "name": name,
            "age": age
        }
        
        users.append(new_user)
        write_json(USERS_FILE, users)
        
        print(json.dumps({
            "status": "success",
            "message": f"User '{name}' added successfully",
            "id": new_id,
            "name": name
        }))
        
    except IndexError:
        print(json.dumps({"status": "error", "message": "Invalid arguments for add user"}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"Failed to add user: {str(e)}"}))
    
    sys.exit(0)


# --- DELETE USER ---
# Command: python main.py --delete user <user_id>
if '--delete' in sys.argv and 'user' in sys.argv:
    try:
        idx = sys.argv.index('user')
        
        if len(sys.argv) < idx + 2:
            print(json.dumps({"status": "error", "message": "Missing user ID"}))
            sys.exit(1)
        
        user_id = int(sys.argv[idx + 1])
        
        users = read_json(USERS_FILE)
        original_count = len(users)
        
        # Filter out the user
        updated_users = [u for u in users if u.get('id') != user_id]
        
        if len(updated_users) == original_count:
            print(json.dumps({"status": "error", "message": "User not found"}))
            sys.exit(1)
        
        write_json(USERS_FILE, updated_users)
        
        # Also delete user's reviews
        reviews = read_json(REVIEWS_FILE)
        updated_reviews = [r for r in reviews if r.get('user_id') != user_id]
        write_json(REVIEWS_FILE, updated_reviews)
        
        # Update product ratings after deleting reviews
        update_all_product_ratings()
        
        print(json.dumps({
            "status": "success",
            "message": f"User {user_id} deleted successfully",
            "id": user_id
        }))
        
    except ValueError:
        print(json.dumps({"status": "error", "message": "User ID must be a number"}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"Failed to delete user: {str(e)}"}))
    
    sys.exit(0)


# --- ADD PRODUCT ---
# Command: python main.py --add product <name> <category> <price>
if '--add' in sys.argv and 'product' in sys.argv:
    try:
        idx = sys.argv.index('product')
        
        if len(sys.argv) < idx + 4:
            print(json.dumps({"status": "error", "message": "Missing product details (name, category, price)"}))
            sys.exit(1)
        
        name = sys.argv[idx + 1].strip()
        category = sys.argv[idx + 2].strip()
        price_str = sys.argv[idx + 3]
        
        if not name or not category:
            print(json.dumps({"status": "error", "message": "Product name and category cannot be empty"}))
            sys.exit(1)
        
        try:
            price = float(price_str)
            if price < 0:
                print(json.dumps({"status": "error", "message": "Price cannot be negative"}))
                sys.exit(1)
        except ValueError:
            print(json.dumps({"status": "error", "message": "Price must be a valid number"}))
            sys.exit(1)
        
        products = read_json(PRODUCTS_FILE)
        
        # Generate new ID (starting from 1000)
        new_id = max([p.get('id', 999) for p in products], default=999) + 1
        
        new_product = {
            "id": new_id,
            "name": name,
            "category": category,
            "price": round(price, 2),
            "avg_rating": 0.0,
            "reviews_count": 0
        }
        
        products.append(new_product)
        write_json(PRODUCTS_FILE, products)
        
        print(json.dumps({
            "status": "success",
            "message": f"Product '{name}' added successfully",
            "id": new_id
        }))
        
    except IndexError:
        print(json.dumps({"status": "error", "message": "Invalid arguments for add product"}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"Failed to add product: {str(e)}"}))
    
    sys.exit(0)


# --- DELETE PRODUCT ---
# Command: python main.py --delete product <product_id>
if '--delete' in sys.argv and 'product' in sys.argv:
    try:
        idx = sys.argv.index('product')
        
        if len(sys.argv) < idx + 2:
            print(json.dumps({"status": "error", "message": "Missing product ID"}))
            sys.exit(1)
        
        product_id = int(sys.argv[idx + 1])
        
        products = read_json(PRODUCTS_FILE)
        original_count = len(products)
        
        # Filter out the product
        updated_products = [p for p in products if p.get('id') != product_id]
        
        if len(updated_products) == original_count:
            print(json.dumps({"status": "error", "message": "Product not found"}))
            sys.exit(1)
        
        write_json(PRODUCTS_FILE, updated_products)
        
        # Also delete product's reviews
        reviews = read_json(REVIEWS_FILE)
        updated_reviews = [r for r in reviews if r.get('product_id') != product_id]
        write_json(REVIEWS_FILE, updated_reviews)
        
        print(json.dumps({
            "status": "success",
            "message": f"Product {product_id} deleted successfully",
            "id": product_id
        }))
        
    except ValueError:
        print(json.dumps({"status": "error", "message": "Product ID must be a number"}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"Failed to delete product: {str(e)}"}))
    
    sys.exit(0)


# --- GET USERS / PRODUCTS ---
# Command: python main.py --get users | python main.py --get products
if '--get' in sys.argv:
    try:
        idx = sys.argv.index('--get')
        
        if len(sys.argv) < idx + 2:
            print(json.dumps({"status": "error", "message": "Missing get target (users or products)"}))
            sys.exit(1)
        
        target = sys.argv[idx + 1].lower()
        
        if target == 'users':
            users = read_json(USERS_FILE)
            print(json.dumps({"users": users}))
            
        elif target == 'products':
            products = read_json(PRODUCTS_FILE)
            
            # Ensure all products have rating fields
            for product in products:
                if 'avg_rating' not in product or 'reviews_count' not in product:
                    avg_rating, reviews_count = calculate_product_ratings(product.get('id'))
                    product['avg_rating'] = avg_rating
                    product['reviews_count'] = reviews_count
            
            print(json.dumps({"products": products}))
            
        else:
            print(json.dumps({"status": "error", "message": f"Invalid get target: {target}. Use 'users' or 'products'"}))
        
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"Failed to retrieve data: {str(e)}"}))
    
    sys.exit(0)


# --- PURCHASE ---
# Command: python main.py --purchase <user_id> <product_id>
if '--purchase' in sys.argv:
    try:
        idx = sys.argv.index('--purchase')
        
        if len(sys.argv) < idx + 3:
            print(json.dumps({"status": "error", "message": "Missing user_id or product_id"}))
            sys.exit(1)
        
        user_id = int(sys.argv[idx + 1])
        product_id = int(sys.argv[idx + 2])
        
        # Validate user and product exist
        if not user_exists(user_id):
            print(json.dumps({"status": "error", "message": "User not found"}))
            sys.exit(1)
        
        if not product_exists(product_id):
            print(json.dumps({"status": "error", "message": "Product not found"}))
            sys.exit(1)
        
        # For now, just confirm the purchase (no purchase history storage)
        print(json.dumps({
            "status": "success",
            "message": f"User {user_id} purchased product {product_id}",
            "user_id": user_id,
            "product_id": product_id
        }))
        
    except ValueError:
        print(json.dumps({"status": "error", "message": "User ID and Product ID must be numbers"}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"Failed to process purchase: {str(e)}"}))
    
    sys.exit(0)


# --- RATE PRODUCT ---
# Command: python main.py --rate <user_id> <product_id> <rating>
if '--rate' in sys.argv:
    try:
        idx = sys.argv.index('--rate')
        
        if len(sys.argv) < idx + 4:
            print(json.dumps({"status": "error", "message": "Missing user_id, product_id, or rating"}))
            sys.exit(1)
        
        user_id = int(sys.argv[idx + 1])
        product_id = int(sys.argv[idx + 2])
        rating = int(sys.argv[idx + 3])
        
        # Validate inputs
        if not user_exists(user_id):
            print(json.dumps({"status": "error", "message": "User not found"}))
            sys.exit(1)
        
        if not product_exists(product_id):
            print(json.dumps({"status": "error", "message": "Product not found"}))
            sys.exit(1)
        
        if rating < 1 or rating > 5:
            print(json.dumps({"status": "error", "message": "Rating must be between 1 and 5"}))
            sys.exit(1)
        
        reviews = read_json(REVIEWS_FILE)
        
        # Check if user already rated this product
        existing_review = next((r for r in reviews if r.get('user_id') == user_id and r.get('product_id') == product_id), None)
        
        if existing_review:
            # Update existing review
            existing_review['rating'] = rating
        else:
            # Add new review
            new_review = {
                "user_id": user_id,
                "product_id": product_id,
                "rating": rating,
                "comment": ""
            }
            reviews.append(new_review)
        
        write_json(REVIEWS_FILE, reviews)
        
        # Update product ratings
        avg_rating, reviews_count = calculate_product_ratings(product_id)
        
        products = read_json(PRODUCTS_FILE)
        for product in products:
            if product.get('id') == product_id:
                product['avg_rating'] = avg_rating
                product['reviews_count'] = reviews_count
                break
        
        write_json(PRODUCTS_FILE, products)
        
        print(json.dumps({
            "status": "success",
            "message": f"Rating submitted successfully",
            "product_id": product_id,
            "new_avg_rating": avg_rating
        }))
        
    except ValueError:
        print(json.dumps({"status": "error", "message": "Invalid input: IDs and rating must be numbers"}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"Failed to submit rating: {str(e)}"}))
    
    sys.exit(0)


# --- RECOMMEND ---
# Command: python main.py --recommend <user_id>
if '--recommend' in sys.argv:
    try:
        idx = sys.argv.index('--recommend')
        
        if len(sys.argv) < idx + 2:
            print(json.dumps({"status": "error", "message": "Missing user_id"}))
            sys.exit(1)
        
        user_id = int(sys.argv[idx + 1])
        
        if not user_exists(user_id):
            print(json.dumps({"status": "error", "message": "User not found"}))
            sys.exit(1)
        
        products = read_json(PRODUCTS_FILE)
        reviews = read_json(REVIEWS_FILE)
        
        # Get products reviewed by this user
        user_reviews = [r for r in reviews if r.get('user_id') == user_id]
        reviewed_product_ids = [r.get('product_id') for r in user_reviews]
        
        if not reviewed_product_ids:
            # User has no reviews, recommend top 3 highest-rated products
            sorted_products = sorted(products, key=lambda p: p.get('avg_rating', 0), reverse=True)
            recommendations = sorted_products[:3]
        else:
            # Get the last reviewed product
            last_review = user_reviews[-1]
            last_product_id = last_review.get('product_id')
            
            # Find category of last reviewed product
            last_product = next((p for p in products if p.get('id') == last_product_id), None)
            
            if last_product:
                target_category = last_product.get('category')
                
                # Find products in same category, not yet reviewed, sorted by rating
                candidates = [
                    p for p in products
                    if p.get('category') == target_category
                    and p.get('id') not in reviewed_product_ids
                ]
                
                sorted_candidates = sorted(candidates, key=lambda p: p.get('avg_rating', 0), reverse=True)
                recommendations = sorted_candidates[:3]
            else:
                recommendations = []
        
        print(json.dumps({
            "status": "success",
            "user_id": user_id,
            "recommendations": recommendations
        }))
        
    except ValueError:
        print(json.dumps({"status": "error", "message": "User ID must be a number"}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": f"Failed to generate recommendations: {str(e)}"}))
    
    sys.exit(0)


# --- DEFAULT (No valid command) ---
print(json.dumps({
    "status": "error",
    "message": "No valid command provided. Use --add, --delete, --get, --purchase, --rate, or --recommend"
}))
sys.exit(1)