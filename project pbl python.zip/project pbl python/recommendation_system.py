import json
import os
import sys
from typing import List, Dict, Any, Optional

# --- Constants ---
PRODUCTS_FILE = "products.json"
USERS_FILE = "users.json"
REVIEWS_FILE = "reviews.json"

# --- Utility Functions for JSON and String Parsing ---

# Python's json.dumps handles escaping, so we can use a simpler utility
def safe_float_conversion(value: Any) -> float:
    """Safely converts a value to a float, returning 0.0 on error."""
    try:
        return float(value)
    except (ValueError, TypeError):
        return 0.0

# --- 1. Review Class ---
class Review:
    def __init__(self, user_id: int, product_id: int, rating: int, comment: str):
        self.user_id = user_id
        self.product_id = product_id
        self.rating = rating
        self.comment = comment

    def to_dict(self) -> Dict[str, Any]:
        return {
            "user_id": self.user_id,
            "product_id": self.product_id,
            "rating": self.rating,
            "comment": self.comment
        }

    # Equivalent to C++'s toJson()
    def to_json(self) -> str:
        return json.dumps(self.to_dict())

# --- 2. Product Class ---
class Product:
    def __init__(self, id: int, name: str, category: str, price: float):
        self.id = id
        self.name = name
        self.category = category
        self.price = price

    def to_dict(self) -> Dict[str, Any]:
        # Price is formatted to 2 decimal places to match C++ output
        return {
            "id": self.id,
            "name": self.name,
            "category": self.category,
            "price": round(self.price, 2)
        }

    # Equivalent to C++'s toJson()
    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(',', ':')) # Use separators for C++ compact style

# --- 3. User Class ---
class User:
    def __init__(self, id: int, name: str):
        self.id = id
        self.name = name

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name
        }

    # Equivalent to C++'s toJson()
    def to_json(self) -> str:
        return json.dumps(self.to_dict())


# --- 4. RecommendationSystem Class ---
class RecommendationSystem:
    def __init__(self):
        self.products: List[Product] = []
        self.users: List[User] = []
        self.reviews: List[Review] = []
        self.next_product_id: int = 1000
        self.next_user_id: int = 100

    def _create_default_data(self):
        """Attempts to create initial default data."""
        self.products.append(Product(1000, "Mechanical Keyboard", "Electronics", 99.99))
        self.products.append(Product(1001, "Wireless Mouse", "Electronics", 45.50))
        self.products.append(Product(1002, "The Silent Patient Book", "Books", 12.00))
        self.products.append(Product(1003, "Blue Hoodie", "Apparel", 65.00))
        self.next_product_id = 1004

        self.users.append(User(100, "Alice Johnson"))
        self.users.append(User(101, "Bob Smith"))
        self.next_user_id = 102

        self.reviews.append(Review(100, 1000, 5, "Excellent keyboard for coding."))
        self.reviews.append(Review(100, 1001, 4, "Reliable mouse, good battery life."))
        self.reviews.append(Review(101, 1002, 3, "A decent thriller, a bit slow."))
        self.reviews.append(Review(101, 1003, 5, "Comfy and warm!"))

    # --- Persistence Methods ---

    def _read_data_file(self, filename: str) -> List[Dict[str, Any]]:
        """Reads and parses a JSON array from a file."""
        if not os.path.exists(filename) or os.stat(filename).st_size == 0:
            sys.stderr.write(f"DEBUG Python: File not found or empty: {filename}\n")
            return []
        try:
            with open(filename, 'r') as f:
                # The C++ version reads the whole file as one JSON string for manual parsing.
                # Python's json.load() is the standard way to handle this.
                data = json.load(f)
                return data if isinstance(data, list) else []
        except json.JSONDecodeError as e:
            sys.stderr.write(f"DEBUG Python: JSON Decode Error in {filename}: {e}\n")
            return []
        except Exception as e:
            sys.stderr.write(f"DEBUG Python: Error reading {filename}: {e}\n")
            return []

    def load_data(self):
        """Reads all data from JSON files into memory."""
        self.products.clear()
        self.users.clear()
        self.reviews.clear()
        data_loaded = False
        
        max_pid = 1000
        # 1. Load Products
        for d in self._read_data_file(PRODUCTS_FILE):
            try:
                self.products.append(Product(d['id'], d['name'], d['category'], safe_float_conversion(d['price'])))
                max_pid = max(max_pid, d['id'] + 1)
                data_loaded = True
            except (KeyError, ValueError, TypeError):
                continue
        self.next_product_id = max_pid
        
        max_uid = 100
        # 2. Load Users
        for d in self._read_data_file(USERS_FILE):
            try:
                self.users.append(User(d['id'], d['name']))
                max_uid = max(max_uid, d['id'] + 1)
                data_loaded = True
            except (KeyError, ValueError, TypeError):
                continue
        self.next_user_id = max_uid
        
        # 3. Load Reviews
        for d in self._read_data_file(REVIEWS_FILE):
            try:
                self.reviews.append(Review(d['user_id'], d['product_id'], d['rating'], d['comment']))
                data_loaded = True
            except (KeyError, ValueError, TypeError):
                continue
        
        # If no persistent data was found, create the default set and save it
        if not data_loaded:
            self._create_default_data()
            self.save_data()

    def save_data(self):
        """Writes all in-memory data back to JSON files."""
        def write_vector(filename, data_list):
            try:
                # Use json.dumps with indent=None and separators for a compact C++ style output
                json_string = "[\n" + ",\n".join([item.to_json() for item in data_list]) + "\n]"
                with open(filename, 'w') as f:
                    f.write(json_string)
            except Exception as e:
                sys.stderr.write(f"DEBUG Python: FAILED to write file: {filename}. Error: {e}\n")

        write_vector(PRODUCTS_FILE, self.products)
        write_vector(USERS_FILE, self.users)
        write_vector(REVIEWS_FILE, self.reviews)

    # --- Helper Methods ---

    def _calculate_average_rating(self, product_id: int) -> float:
        """Helper to calculate the average rating for a product."""
        ratings = [r.rating for r in self.reviews if r.product_id == product_id]
        return sum(ratings) / len(ratings) if ratings else 0.0

    def _get_review_count(self, product_id: int) -> int:
        """Helper to get the number of reviews for a product."""
        return sum(1 for r in self.reviews if r.product_id == product_id)

    def _find_product_by_id(self, product_id: int) -> Optional[Product]:
        """Helper to find a Product object by ID."""
        return next((p for p in self.products if p.id == product_id), None)

    def _find_user_by_id(self, user_id: int) -> Optional[User]:
        """Helper to find a User object by ID."""
        return next((u for u in self.users if u.id == user_id), None)

    def _has_user_reviewed(self, user_id: int, product_id: int) -> bool:
        """Helper to check if a user has reviewed a product."""
        return any(r.user_id == user_id and r.product_id == product_id for r in self.reviews)
    
    def _get_reviewed_product_ids(self, user_id: int) -> List[int]:
        """Helper to get all product IDs reviewed by a user, maintaining insertion order (C++ vector behavior)."""
        # Note: Using the review list directly to maintain the insertion order from C++
        return [r.product_id for r in self.reviews if r.user_id == user_id]

    # --- JSON Getters (Read Operations) ---

    def get_products_json(self) -> str:
        """Returns all products with their calculated average rating in the required JSON format."""
        self.load_data()
        product_list_dicts = []
        for p in self.products:
            p_dict = p.to_dict()
            p_dict["avg_rating"] = round(self._calculate_average_rating(p.id), 2)
            p_dict["reviews_count"] = self._get_review_count(p.id)
            product_list_dicts.append(p_dict)
            
        # The C++ output is "{\"products\":[...]}"
        return json.dumps({"products": product_list_dicts}, separators=(',', ':'))

    def get_users_json(self) -> str:
        """Returns all users in the required JSON format."""
        self.load_data()
        user_list_dicts = [u.to_dict() for u in self.users]
        return json.dumps({"users": user_list_dicts}, separators=(',', ':'))

    def get_reviews_json(self, product_id: int) -> str:
        """Returns all reviews for a specific product in the required JSON format."""
        self.load_data()
        reviews_list_dicts = [r.to_dict() for r in self.reviews if r.product_id == product_id]
        return json.dumps({"product_id": product_id, "reviews": reviews_list_dicts}, separators=(',', ':'))

    # --- JSON Adders (Create/Update Operations) ---

    def add_user(self, name: str) -> str:
        """Adds a new user and saves data."""
        self.load_data() 
        new_id = self.next_user_id
        self.next_user_id += 1
        self.users.append(User(new_id, name))
        self.save_data()
        
        return json.dumps({
            "status": "success", 
            "message": "User added successfully.", 
            "id": new_id, 
            "name": name
        })

    def add_product(self, name: str, category: str, price: float) -> str:
        """Adds a new product and saves data."""
        self.load_data()
        new_id = self.next_product_id
        self.next_product_id += 1
        self.products.append(Product(new_id, name, category, price))
        self.save_data()

        return json.dumps({
            "status": "success", 
            "message": "Product added successfully.", 
            "id": new_id
        })
    
    def purchase_product(self, user_id: int, product_id: int) -> str:
        """Checks existence of user/product and provides a purchase confirmation."""
        self.load_data()
        
        if self._find_user_by_id(user_id) is None: 
            return json.dumps({"status": "error", "message": "User not found."})
        if self._find_product_by_id(product_id) is None: 
            return json.dumps({"status": "error", "message": "Product not found."})
        
        # Matching the C++ comment/behavior for a simple purchase check
        return json.dumps({
            "status": "success", 
            "message": "Purchase recorded (no dedicated purchase history storage in this C++ version)."
        })

    def rate_product(self, user_id: int, product_id: int, rating: int) -> str:
        """Rates a product (redirects to add_review with no comment)."""
        return self.add_review(user_id, product_id, rating, "No comment provided.")


    def add_review(self, user_id: int, product_id: int, rating: int, comment: str) -> str:
        """Adds a new review and saves data."""
        self.load_data()

        if self._find_user_by_id(user_id) is None: 
            return json.dumps({"status": "error", "message": "User not found."})
        if self._find_product_by_id(product_id) is None: 
            return json.dumps({"status": "error", "message": "Product not found."})
        if not (1 <= rating <= 5): 
            return json.dumps({"status": "error", "message": "Invalid rating (1-5)."})
        
        if self._has_user_reviewed(user_id, product_id): 
            return json.dumps({"status": "error", "message": "User has already reviewed this product."})

        self.reviews.append(Review(user_id, product_id, rating, comment))
        self.save_data()
        
        new_avg_rating = round(self._calculate_average_rating(product_id), 6) # Use high precision for to_string match
        
        # Match C++ string formatting closely
        return '{"status":"success", "message":"Review added.", "product_id":' + str(product_id) + ', "new_avg_rating":' + str(new_avg_rating) + '}'

    def delete_user(self, user_id: int) -> str:
        """Deletes a user and their reviews."""
        self.load_data()
        
        initial_user_count = len(self.users)
        self.users = [u for u in self.users if u.id != user_id]
        
        if len(self.users) == initial_user_count:
            return json.dumps({"status": "error", "message": "User not found."})
        
        # Remove all reviews by this user
        self.reviews = [r for r in self.reviews if r.user_id != user_id]
        
        self.save_data()
        return json.dumps({
            "status": "success", 
            "message": "User deleted successfully.", 
            "id": user_id
        })

    def delete_product(self, product_id: int) -> str:
        """Deletes a product and its reviews."""
        self.load_data()
        
        initial_product_count = len(self.products)
        self.products = [p for p in self.products if p.id != product_id]
        
        if len(self.products) == initial_product_count:
            return json.dumps({"status": "error", "message": "Product not found."})
        
        # Remove all reviews for this product
        self.reviews = [r for r in self.reviews if r.product_id != product_id]
        
        self.save_data()
        return json.dumps({
            "status": "success", 
            "message": "Product deleted successfully.", 
            "id": product_id
        })

    def get_recommendations_json(self, user_id: int) -> str:
        """
        Generates recommendations based on the category of the last reviewed product.
        Logic: Match category, not reviewed, sort by avg rating (descending), take top 3.
        """
        self.load_data()
        
        user = self._find_user_by_id(user_id)
        if user is None: 
            return json.dumps({"status": "error", "message": "User not found."})

        # 1. Find the category of the last reviewed product
        reviewed_ids = self._get_reviewed_product_ids(user_id)
        if not reviewed_ids: 
            return json.dumps({"status": "error", "message": "User has no review history for recommendations."})

        last_reviewed_id = reviewed_ids[-1]
        last_product = self._find_product_by_id(last_reviewed_id)
        
        if last_product is None: 
            return json.dumps({"status": "error", "message": "Internal data error: Last reviewed product missing."})

        target_category = last_product.category

        # 2. Filter and collect relevant products (same category, not reviewed)
        candidates = [] # list of (avg_rating, product_object)
        for product in self.products:
            # Must match category AND not be already reviewed by the user
            if product.category == target_category and not self._has_user_reviewed(user_id, product.id):
                avg_rating = self._calculate_average_rating(product.id)
                candidates.append((avg_rating, product))

        if not candidates:
            return json.dumps({
                "status": "success", 
                "user_id": user_id, 
                "recommendations": [], 
                "message": f"No new recommendations available in category {target_category}."
            })

        # 3. Sort candidates by average rating (descending)
        candidates.sort(key=lambda x: x[0], reverse=True)

        # 4. Build JSON for top 3 recommendations
        recommendations_list = []
        for avg_rating, product in candidates[:3]:
            # Manually construct JSON dict to include the rating
            p_dict = product.to_dict()
            p_dict["avg_rating"] = round(avg_rating, 2)
            p_dict["reviews_count"] = self._get_review_count(product.id)
            recommendations_list.append(p_dict)
            
        # The C++ output is "{\"status\":\"success\",...}"
        output_dict = {
            "status": "success",
            "user_id": user_id,
            "target_category": target_category,
            "recommendations": recommendations_list
        }
        
        return json.dumps(output_dict, separators=(',', ':'))

# This block is not executed when imported but is kept for structure parity
if __name__ == '__main__':
    pass # No main entry point here, it's in main.py