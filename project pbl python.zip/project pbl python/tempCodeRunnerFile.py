import json
from flask import Flask, jsonify, request
import subprocess
import os
import sys
from flask_cors import CORS

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # enable frontend communication

# --- Helper Function to run the Python backend ---
def run_python_command(args):
    """
    Runs the Python logic file (main.py or recommendation_system.py)
    with given arguments and expects clean JSON output.
    Returns (data, status_code).
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))
    script_path = ''

    # Priority order: check for logic files
    possible_scripts = [
        'recommendation_system.py',
        'main.py'
    ]

    for name in possible_scripts:
        full_path = os.path.join(base_dir, name)
        if os.path.exists(full_path):
            script_path = full_path
            break

    if not script_path:
        print(f"ERROR: Python logic file not found in {base_dir}", file=sys.stderr)
        return {"error": "Python logic file not found. Please add main.py or recommendation_system.py."}, 500

    command = ['python', script_path] + args

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            encoding='utf-8',
            timeout=10
        )
        output = result.stdout.strip()
        
        print(f"DEBUG: Command: {' '.join(command)}", file=sys.stderr)
        print(f"DEBUG: Raw Python Output: {output}", file=sys.stderr)

        if not output:
            error_output = result.stderr.strip()
            if error_output:
                print(f"DEBUG: Python stderr: {error_output}", file=sys.stderr)
                return {"error": "Python logic failed", "stderr": error_output}, 500
            return {"error": "Python script returned no output."}, 500

        try:
            data = json.loads(output)
            return data, 200
        except json.JSONDecodeError as e:
            print(f"DEBUG: JSON decode error: {e}", file=sys.stderr)
            return {"error": "Invalid JSON from Python script", "raw_output": output}, 500

    except subprocess.TimeoutExpired:
        return {"error": "Python logic timed out."}, 504
    except Exception as e:
        print(f"DEBUG: Exception: {e}", file=sys.stderr)
        return {"error": f"Unexpected server error: {str(e)}"}, 500


# --- ROUTES ---

@app.route('/')
def index():
    return jsonify({
        "status": "OK",
        "message": "E-Commerce Recommendation System API is running!"
    }), 200


# --- GET ROUTES ---

@app.route('/get/products', methods=['GET'])
@app.route('/getProducts', methods=['GET'])
def get_products():
    try:
        data, status = run_python_command(["--get", "products"])
        if not isinstance(data, dict):
            return jsonify({"error": "Invalid data from backend"}), 500
        return jsonify(data), status
    except Exception as e:
        return jsonify({"error": f"Failed to get products: {str(e)}"}), 500


@app.route('/get/users', methods=['GET'])
@app.route('/getUsers', methods=['GET'])
def get_users():
    try:
        data, status = run_python_command(["--get", "users"])
        if not isinstance(data, dict):
            return jsonify({"error": "Invalid data from backend"}), 500
        return jsonify(data), status
    except Exception as e:
        return jsonify({"error": f"Failed to get users: {str(e)}"}), 500


@app.route('/get/reviews/<int:product_id>', methods=['GET'])
@app.route('/getReviews/<int:product_id>', methods=['GET'])
def get_reviews(product_id):
    try:
        data, status = run_python_command(["--get", "reviews", str(product_id)])
        if not isinstance(data, dict):
            return jsonify({"error": "Invalid data from backend"}), 500
        return jsonify(data), status
    except Exception as e:
        return jsonify({"error": f"Failed to get reviews: {str(e)}"}), 500


# --- ADD/ACTION ROUTES ---

@app.route('/add/user', methods=['POST'])
@app.route('/addUser', methods=['POST'])
def add_user():
    try:
        body = request.get_json(force=True)
        user_name = body.get('name')
        if not user_name:
            return jsonify({"error": "Missing user name"}), 400

        data, status = run_python_command(["--add", "user", user_name])
        return jsonify(data), status
    except Exception as e:
        return jsonify({"error": f"Failed to add user: {str(e)}"}), 400


@app.route('/add/product', methods=['POST'])
@app.route('/addProduct', methods=['POST'])
def add_product():
    try:
        body = request.get_json(force=True)
        name = body.get("name")
        price = body.get("price")
        category = body.get("category", "General")

        if not name or not price:
            return jsonify({"error": "Missing product name or price"}), 400

        data, status = run_python_command(["--add", "product", name, category, str(price)])
        return jsonify(data), status
    except Exception as e:
        return jsonify({"error": f"Failed to add product: {str(e)}"}), 400


@app.route('/purchase', methods=['POST'])
def purchase():
    try:
        body = request.get_json(force=True)
        userId = str(body.get("userId"))
        productId = str(body.get("productId"))

        if not userId or not productId:
            return jsonify({"error": "Missing userId or productId"}), 400

        data, status = run_python_command(["--purchase", userId, productId])
        return jsonify(data), status
    except Exception as e:
        return jsonify({"error": f"Failed to complete purchase: {str(e)}"}), 400


@app.route('/rate', methods=['POST'])
def rate():
    try:
        body = request.get_json(force=True)
        userId = str(body.get("userId"))
        productId = str(body.get("productId"))
        rating = str(body.get("rating"))

        if not userId or not productId or not rating:
            return jsonify({"error": "Missing userId, productId, or rating"}), 400

        data, status = run_python_command(["--rate", userId, productId, rating])
        return jsonify(data), status
    except Exception as e:
        return jsonify({"error": f"Failed to rate product: {str(e)}"}), 400


@app.route('/recommend', methods=['GET'])
def recommend():
    try:
        userId = request.args.get('userId')
        if not userId:
            return jsonify({"error": "Missing userId"}), 400

        data, status = run_python_command(["--recommend", str(userId)])
        return jsonify(data), status
    except Exception as e:
        return jsonify({"error": f"Failed to get recommendations: {str(e)}"}), 400


@app.route('/delete/user/<int:user_id>', methods=['DELETE'])
@app.route('/deleteUser/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    try:
        data, status = run_python_command(["--delete", "user", str(user_id)])
        return jsonify(data), status
    except Exception as e:
        return jsonify({"error": f"Failed to delete user: {str(e)}"}), 400


@app.route('/delete/product/<int:product_id>', methods=['DELETE'])
@app.route('/deleteProduct/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    try:
        data, status = run_python_command(["--delete", "product", str(product_id)])
        return jsonify(data), status
    except Exception as e:
        return jsonify({"error": f"Failed to delete product: {str(e)}"}), 400


# --- Run Flask App ---
if __name__ == '__main__':
    print("=" * 60)
    print("🚀 E-Commerce Recommendation System API Starting...")
    print("=" * 60)
    print("📍 Server will run at: http://127.0.0.1:5000")
    print("📂 Make sure these files exist in the same directory:")
    print("   - main.py or recommendation_system.py")
    print("   - products.json, users.json, reviews.json (in data/ folder)")
    print("=" * 60)
    app.run(debug=True, port=5000)